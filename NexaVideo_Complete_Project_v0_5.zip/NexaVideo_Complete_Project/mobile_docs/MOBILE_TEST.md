# NexaVideo Mobile Test

## Fastest route: GitHub Actions
1. Create a GitHub repository.
2. Upload this complete project.
3. Open **Actions → Build NexaVideo APK → Run workflow**.
4. Wait for the build to finish.
5. Open the completed workflow run and download the **nexavideo-debug-apk** artifact.
6. Extract it on Android and install `app-debug.apk`.

## Important
The APK is a development/test build. The app's API base URL is configured in `android/app/src/main/java/com/nexavideo/data/ApiClient.kt`.
The backend must be reachable from the phone for login/feed/API features to work.

For a local backend, do not use `localhost` from the phone: `localhost` means the phone itself. Use the computer's LAN IP or a deployed HTTPS API.
