# NexaVideo — Integrated MVP v0.4.0

Original Android-first video/social platform source foundation. This package now combines the major planned systems into one project: authentication, profiles, feed, videos/upload sessions, shorts, likes/comments/follows, saves, views/watch tracking, notifications, messaging, creator stats/earnings data model, reports/moderation data model, search, PostgreSQL and Docker.

## What is runnable now
- Backend: Node.js + Express + PostgreSQL.
- Android: Jetpack Compose app with login/register, Home feed, Shorts, Create, Inbox and Profile shells connected to the API.
- Database: PostgreSQL schema with social, creator, safety, analytics and monetization tables.
- Docker: PostgreSQL + API + persistent local upload volume.

## Quick local test
1. Install Docker Desktop and Android Studio.
2. From `infrastructure/`, run `docker compose up --build`.
3. API health: `http://localhost:8080/health` should return database `ok`.
4. Open `android/` in Android Studio, let Gradle sync, run on an emulator. The Android API base URL is `http://10.0.2.2:8080/` for the emulator.
5. Create an account in the app, then the Home screen requests the real PostgreSQL-backed feed.

## Important production work still requires external services
This source cannot create cloud accounts or production credentials by itself. Before Play Store launch, connect object storage/CDN, real video transcoding, production streaming/live infrastructure, push notifications, payment/payout provider, AI provider keys, email/SMS verification, domain/TLS, monitoring/logging, secrets management, Play signing and Play Console.

The project is **not claimed to be already live or published**. It is a consolidated, runnable development/MVP source package intended for testing and continued production integration.

## Cloud APK build
A GitHub Actions workflow is included at `.github/workflows/android-apk.yml`. It builds the debug APK in the cloud and uploads it as the `nexavideo-debug-apk` artifact, so a computer with Android Studio is not required for the build itself. See `mobile_docs/MOBILE_TEST.md`.
