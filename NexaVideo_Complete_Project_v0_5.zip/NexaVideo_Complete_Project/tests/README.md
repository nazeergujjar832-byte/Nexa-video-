# Tests

Backend smoke/contract tests should run with `npm test` after adding integration fixtures. CI should cover auth, feed, upload permissions, social actions, messaging, moderation and payment webhooks.

Before production, add ephemeral PostgreSQL integration tests and Android unit/UI tests.
