#!/usr/bin/env bash
set -euo pipefail
curl -fsS http://localhost:8080/health
echo
curl -fsS http://localhost:8080/api/v1/health/details
echo
