package com.nexavideo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nexavideo.data.*
import kotlinx.coroutines.launch

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{NexaVideoApp()}}}
class AppViewModel:ViewModel(){
 var loggedIn by mutableStateOf(false); private set
 var user by mutableStateOf<User?>(null); private set
 var videos by mutableStateOf<List<Video>>(emptyList()); private set
 var shorts by mutableStateOf<List<ShortItem>>(emptyList()); private set
 var error by mutableStateOf<String?>(null); private set
 fun login(u:String,p:String){call{val r=ApiClient.api.login(AuthRequest(u,p));Session.token=r.accessToken;Session.refreshToken=r.refreshToken;user=r.user;loggedIn=true;loadFeed()}}
 fun register(u:String,p:String,e:String?){call{val r=ApiClient.api.register(AuthRequest(u,p,e));Session.token=r.accessToken;Session.refreshToken=r.refreshToken;user=r.user;loggedIn=true;loadFeed()}}
 fun loadFeed(){call{videos=ApiClient.api.feed().items}}
 fun loadShorts(){call{shorts=ApiClient.api.shorts()}}
 fun like(id:String){call{ApiClient.api.like(id);loadFeed()}}
 fun logout(){Session.token=null;Session.refreshToken=null;loggedIn=false;user=null}
 private fun call(block:suspend()->Unit){viewModelScope.launch{error=null;runCatching{block()}.onFailure{error=it.message?:"Request failed"}}}
}
@Composable fun NexaVideoApp(vm:AppViewModel=viewModel()){if(vm.loggedIn)MainShell(vm)else Login(vm)}
@Composable fun Login(vm:AppViewModel){var reg by remember{mutableStateOf(false)};var u by remember{mutableStateOf("")};var p by remember{mutableStateOf("")};var e by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center){Text("NexaVideo",style=MaterialTheme.typography.headlineLarge);Text("Video • Shorts • Creators • Community");Spacer(Modifier.height(18.dp));OutlinedTextField(u,{u=it},label={Text("Username / Email")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp));if(reg){OutlinedTextField(e,{e=it},label={Text("Email (optional)")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp))};OutlinedTextField(p,{p=it},label={Text("Password (8+ characters)")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(12.dp));Button({if(reg)vm.register(u,p,e.ifBlank{null})else vm.login(u,p)},Modifier.fillMaxWidth()){Text(if(reg)"Create account" else "Login")};TextButton({reg=!reg}){Text(if(reg)"Already have an account? Login" else "Create account")};vm.error?.let{Text(it,color=MaterialTheme.colorScheme.error)}}}
@Composable fun MainShell(vm:AppViewModel){var tab by remember{mutableIntStateOf(0)};val tabs=listOf("Home","Shorts","Create","Inbox","Profile");Scaffold(bottomBar={NavigationBar{tabs.forEachIndexed{i,t->NavigationBarItem(i==tab,{tab=i},icon={},label={Text(t)})}}}){p->when(tab){0->Home(vm,Modifier.padding(p));1->Shorts(vm,Modifier.padding(p));2->Create(vm,Modifier.padding(p));3->Inbox(Modifier.padding(p));4->Profile(vm,Modifier.padding(p))}}}
@Composable fun Home(vm:AppViewModel,m:Modifier){LaunchedEffect(Unit){vm.loadFeed()};LazyColumn(m.padding(16.dp)){item{Text("For You",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp))};items(vm.videos){v->Card(Modifier.fillMaxWidth().padding(bottom=10.dp)){Column(Modifier.padding(16.dp)){Text(v.title,style=MaterialTheme.typography.titleLarge);Text("@${v.username?:"creator"} • ${v.views} views • ${v.likes} likes");v.description?.let{Text(it,maxLines=2)};Row{Button({vm.like(v.id)}){Text("Like")};Spacer(Modifier.width(8.dp));TextButton({}){Text("Comments ${v.comments_count}")}}}}};item{vm.error?.let{Text(it,color=MaterialTheme.colorScheme.error)}}}}
@Composable fun Shorts(vm:AppViewModel,m:Modifier){LaunchedEffect(Unit){vm.loadShorts()};LazyColumn(m.padding(16.dp)){item{Text("Shorts",style=MaterialTheme.typography.headlineMedium)};items(vm.shorts){s->Card(Modifier.fillMaxWidth().padding(vertical=8.dp)){Column(Modifier.padding(16.dp)){Text(s.title?:"Untitled Short",style=MaterialTheme.typography.titleLarge);Text("${s.views} views • ${s.duration_seconds?:0}s");Text(s.video_url?:"Video ready for playback")}}}}}
@Composable fun Create(vm:AppViewModel,m:Modifier){Column(m.padding(24.dp)){Text("Create",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp));Text("Upload video / create Short / go Live");Spacer(Modifier.height(12.dp));Button({}){Text("Choose video")};Text("Upload processing, thumbnails and live streaming connect to the production storage/streaming providers.",style=MaterialTheme.typography.bodySmall)}}
@Composable fun Inbox(m:Modifier){Column(m.padding(24.dp)){Text("Inbox",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp));Text("Messages and notifications are connected through the API. Select a conversation after the user ID is available.")}}
@Composable fun Profile(vm:AppViewModel,m:Modifier){Column(m.padding(24.dp)){Text(vm.user?.display_name?:vm.user?.username?:"Profile",style=MaterialTheme.typography.headlineMedium);Text(vm.user?.email?:"");Spacer(Modifier.height(16.dp));Button({vm.logout()}){Text("Logout")};Spacer(Modifier.height(8.dp));Text("Creator Studio • Earnings • Settings • Safety")}}
