package com.nexavideo.data

import retrofit2.http.*

data class AuthRequest(val username:String,val password:String,val email:String?=null)
data class AuthResponse(val user:User,val accessToken:String,val refreshToken:String)
data class User(val id:String,val username:String,val email:String?,val display_name:String?=null,val avatar_url:String?=null,val bio:String?=null)
data class Video(val id:String,val title:String,val description:String?,val thumbnail_url:String?,val playback_url:String?,val duration_seconds:Int?,val views:Long,val likes:Long,val comments_count:Long,val username:String?,val display_name:String?,val avatar_url:String?)
data class FeedResponse(val items:List<Video>,val nextCursor:String?)
data class ShortItem(val id:String,val video_url:String?,val thumbnail_url:String?,val title:String?,val duration_seconds:Int?,val views:Long)
data class CommentRequest(val text:String)
data class Comment(val id:String,val text:String,val created_at:String,val username:String?,val display_name:String?,val avatar_url:String?)
data class MessageRequest(val body:String)
data class Message(val id:String,val sender_id:String,val recipient_id:String,val body:String?,val created_at:String)
data class UploadSessionRequest(val title:String,val description:String?=null,val durationSeconds:Int?=null,val visibility:String="PUBLIC")
data class UploadSession(val videoId:String,val uploadUrl:String,val expiresInSeconds:Int)
data class ProfileUpdate(val displayName:String?=null,val bio:String?=null,val avatarUrl:String?=null,val country:String?=null,val language:String?=null)
data class ReportRequest(val targetType:String,val targetId:String,val reason:String)

interface NexaApi {
 @POST("api/v1/auth/register") suspend fun register(@Body body:AuthRequest):AuthResponse
 @POST("api/v1/auth/login") suspend fun login(@Body body:AuthRequest):AuthResponse
 @POST("api/v1/auth/refresh") suspend fun refresh(@Body body:Map<String,String>):Map<String,String>
 @GET("api/v1/me") suspend fun me():User
 @PATCH("api/v1/me") suspend fun updateMe(@Body body:ProfileUpdate):User
 @GET("api/v1/feed") suspend fun feed(@Query("limit") limit:Int=20,@Query("cursor") cursor:String?=null):FeedResponse
 @GET("api/v1/shorts") suspend fun shorts():List<ShortItem>
 @POST("api/v1/videos/{id}/view") suspend fun view(@Path("id") id:String)
 @POST("api/v1/videos/{id}/watch") suspend fun watch(@Path("id") id:String,@Body body:Map<String,Any>)
 @POST("api/v1/videos/{id}/like") suspend fun like(@Path("id") id:String)
 @DELETE("api/v1/videos/{id}/like") suspend fun unlike(@Path("id") id:String)
 @POST("api/v1/videos/{id}/comments") suspend fun comment(@Path("id") id:String,@Body body:CommentRequest):Comment
 @GET("api/v1/videos/{id}/comments") suspend fun comments(@Path("id") id:String):List<Comment>
 @POST("api/v1/videos/{id}/save") suspend fun save(@Path("id") id:String)
 @DELETE("api/v1/videos/{id}/save") suspend fun unsave(@Path("id") id:String)
 @POST("api/v1/users/{id}/follow") suspend fun follow(@Path("id") id:String)
 @DELETE("api/v1/users/{id}/follow") suspend fun unfollow(@Path("id") id:String)
 @GET("api/v1/notifications") suspend fun notifications():List<Map<String,Any>>
 @POST("api/v1/notifications/read-all") suspend fun readNotifications()
 @GET("api/v1/messages/{userId}") suspend fun messages(@Path("userId") id:String):List<Message>
 @POST("api/v1/messages/{userId}") suspend fun sendMessage(@Path("userId") id:String,@Body body:MessageRequest):Message
 @POST("api/v1/videos/upload-session") suspend fun uploadSession(@Body body:UploadSessionRequest):UploadSession
 @GET("api/v1/creator/stats") suspend fun creatorStats():Map<String,Any>
 @POST("api/v1/reports") suspend fun report(@Body body:ReportRequest)
}
