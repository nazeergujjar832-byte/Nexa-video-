package com.nexavideo.data
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object Session { var token:String?=null; var refreshToken:String?=null }
object ApiClient {
 private const val BASE_URL="http://10.0.2.2:8080/"
 private val interceptor=Interceptor{chain->chain.proceed(chain.request().newBuilder().apply{Session.token?.let{header("Authorization","Bearer $it")}}.build())}
 private val client=OkHttpClient.Builder().addInterceptor(interceptor).addInterceptor(HttpLoggingInterceptor().apply{level=HttpLoggingInterceptor.Level.BASIC}).build()
 val api:NexaApi=Retrofit.Builder().baseUrl(BASE_URL).client(client).addConverterFactory(GsonConverterFactory.create()).build().create(NexaApi::class.java)
}
